To run web:
Unzip app.zip
Open Python IDE or run code from cli.
Run `main.py
Open http://localhost:8080/` in your browser
Run simulation
